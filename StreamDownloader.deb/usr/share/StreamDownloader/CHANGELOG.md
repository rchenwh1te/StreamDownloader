# Changelog

## v2.3.0
Moved from JSON dataset to a more stable sql database.

## v2.2.5
Improved user interface. Removed textual interface to reduce size. Added executable installer for windows.

## v2.2.0
Fixed bugs, added features, seperated merge classes, made more universal.

## v2.1.5
Not released. Fixed bugs.

## v2.1.0
Not released. Fixed bugs, added features.

## v2.0.5
Added download location selector. Added install script for easier installation. Made usage simpler by only typing in one command set by user. Made GUI into default.

## v2.0.0
Major changes. Added graphical user interface and opera dataset. Added error handlers.

## v1.0.6
Made completely platform independent. Compilation errors fixed.

## v1.0.4
Improved user interface, lighter, uses less resources. Non platform-dependent. Added auto-detect to websites.

## v1.0.3
Not published. Split source to multiple files, first attempt at downloading other streaming sites.

## v1.0.2
Very buggy version. First attempt at cross-platform, better user interface.

## v1.0.1
Added multithreading, downloading everything simutaneously.

## v1.0.0:
Uploaded to github. Basic performance, Keeps all files until completion.
