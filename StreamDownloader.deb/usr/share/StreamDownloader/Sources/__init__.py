from . import MyFidelio
from . import Merge
from . import themes
from . import settings
